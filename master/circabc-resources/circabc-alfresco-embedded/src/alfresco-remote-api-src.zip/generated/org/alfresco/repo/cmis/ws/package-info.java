@javax.xml.bind.annotation.XmlSchema(namespace = "http://docs.oasis-open.org/ns/cmis/messaging/200908/", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package org.alfresco.repo.cmis.ws;
